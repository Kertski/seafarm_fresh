@extends('layouts.admin')

@section('content')
    <div class='card'>
        <div  class='card-body'>
            <h1>
                Seafarm Fresh
            </h1>
        </div>
    </div>
@endsection