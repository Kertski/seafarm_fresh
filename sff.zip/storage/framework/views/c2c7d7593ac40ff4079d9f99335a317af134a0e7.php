

<?php $__env->startSection('title'); ?>
    My Cart
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="py-3 mb-4 shadow-sm bg-warning border-top">
        <div class="container">
            <h6 class="mb-8"><a href="<?php echo e(url('/')); ?>" >Home</a> / Cart </h6>
        </div>
    </div>

    <div class="container my-5">
        <div class="card shadow cartitems">
            <?php if($cartitems->count()>0): ?>
            <div class="card-body">
                <?php $total = 0; ?>
                <?php $__currentLoopData = $cartitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row product_data">
                    <div class="col-md-2">
                        <img src="<?php echo e(asset('assets/uploads/products/'.$item->products->image)); ?>" alt="image here" height="70px">
                    </div>
                    <div class="col-md-3">
                        <h3><?php echo e($item->products->name); ?></h3>
                    </div>
                    <div class="col-md-3">
                        
                        <h3>Php <?php echo e($item->products->selling_price * $item->prod_qty); ?></h3>
                    </div>
                    <div class="col-md-3">
                        <input type="hidden" class="prod_id" value="<?php echo e($item->prod_id); ?>">
                        <label for="Quantity">Quantity</label>
                        <div class="input-group text-center mb-3" style="width: 130px">
                            <span class="input-group-text changeQuantity decrement-btn">-</span>
                            <input type="text" name="quantity" class="form-control qty_input text-center" value="<?php echo e($item->prod_qty); ?>"/>
                            <span class="input-group-text changeQuantity increment-btn">+</span>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-danger mt-4 remove-cart-item"><i class="fa fa-trash"></i> Remove</button>
                    </div>
                </div>
                <?php $total += $item->products->selling_price * $item->prod_qty ; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="card-footer">
                <h6>Total Price: Php <?php echo e($total); ?></h6>
                <a href="<?php echo e(url('checkout')); ?>"class="btn btn-success">Proceed to Checkout</a>
            </div>
            <?php else: ?>
                <div class="card-body text-center">
                    <h2> Cart is Empty </h2>
                    <a href="<?php echo e(url('category')); ?>" class="btn btn-outline-primary float-end"> Shop Now </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Capstone\seafarmfresh\resources\views/frontend/cart.blade.php ENDPATH**/ ?>