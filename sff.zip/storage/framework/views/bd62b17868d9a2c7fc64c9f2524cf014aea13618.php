

<?php $__env->startSection('title'); ?>
    <?php echo e($category->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="py-3 mb-4 shadow-sm bg-warning border-top">
    <div class="container">
        <h6 class="mb-8"><a href="<?php echo e(url('category')); ?>"><?php echo e($category->name); ?></a></h6>
    </div>
</div>

<div class="py-5">
    <div class="container">
        <div class="row">
            <h2 class="category_page_name"><?php echo e($category->name); ?></h2>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 mb-3">
                        <div class="card product-card">
                            <a href="<?php echo e(url('category/'.$category->slug.'/'.$prod->slug)); ?>">
                                <img src="<?php echo e(asset('assets/uploads/products/'.$prod->image)); ?>" alt="Product Image" width="100%">
                                <div class="card-body product_name pb-5">
                                    <h5 class="product_name"><?php echo e($prod->name); ?></h5>
                                    <span class="float-start before_price product_price">₱ <?php echo e($prod->selling_price); ?>.00</span>
                                    <span class="float-end product_price orig_price">₱ <?php echo e($prod->original_price); ?>.00</span>
                                </div>
                            </a>
                        </div>
                    </div>
                </a>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Capstone\seafarmfresh\resources\views/frontend/products/index.blade.php ENDPATH**/ ?>