<nav class="navbar navbar-dark navbar-expand-xl navbar_cont navbar-absolute fixed-top">
    <div class="ms-3">
      <a class="navbar-brand" href="#"><img src="<?php echo e(asset('assets/images/seafarm-logo-white.png')); ?>" alt="Seafarm Fresh" width="220px"></a>
    </div>
      <button class="navbar-toggler me-2" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="<?php echo e(url('/')); ?>">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('category')); ?>">Products</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('blog')); ?>">Blog</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('about-us')); ?>">About Us</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('contact-us')); ?>">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('cart')); ?>"><i class="fa fa-shopping-cart">

            </i>
              <span class="badge badge-pill bg-white cart-count"></span>
            </a>
          </li>
        </ul>
        <ul class="navbar-nav ms-auto">
          <div class="search-bar">
            <form action="<?php echo e(url('searchproduct')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <div class="input-group">
                <input type="search" class="form-control nav-search-input" name="product_name" id="search_product" placeholder="Search products" aria-describedby="basic-addon1">
                <button type="submit" class="input-group-text search-icon-button" id="basic-addon1" ><i class="fa fa-search"></i></button>
              </div>
            </form>
          </div>
          <?php if(auth()->guard()->guest()): ?>
              <?php if(Route::has('login')): ?>
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                  </li>
              <?php endif; ?>

              <?php if(Route::has('register')): ?>
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                  </li>
              <?php endif; ?>
          <?php else: ?>
          <li class="nav-item dropdown pe-3">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <?php echo e(Auth::user()->user_name); ?>

              </a>
              <ul class="dropdown-menu">
                <li>
                  <a class="dropdown-item" href="<?php echo e(url('my-orders')); ?>">
                      My Orders
                  </a>
                </li>
                <li>
                  <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"  onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                      <?php echo e(__('Logout')); ?>

                  </a>
                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                      <?php echo csrf_field(); ?>
                  </form>
                </li>                             
              </ul>
            </li>
          <?php endif; ?>
      </ul>
      </div>
  </nav><?php /**PATH D:\Capstone\seafarmfresh\resources\views/layouts/inc/frontnavbar.blade.php ENDPATH**/ ?>