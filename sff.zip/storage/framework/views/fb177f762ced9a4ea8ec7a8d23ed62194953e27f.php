

<?php $__env->startSection('title'); ?>
    My Orders
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card view-order-card">
                    <div class="card-header">
                        <h4>Orders</h4>
                        <a href="<?php echo e(url('my-orders')); ?>" class="btn btn-warning">Back</a>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h4>Shipping Details</h4>
                                <label for="">STATUS:</label>
                                <?php if($orders->status == '0'): ?>
                                <div class="py-2">Pending</div>
                                <?php elseif($orders->status == '1'): ?>
                                <div class="py-2">To Ship:</div>
                                <?php elseif($orders->status == '2'): ?>
                                <div class="py-2">On Delivery</div>
                                <?php elseif($orders->status == '3'): ?>
                                <div class="py-2">Received</div>
                                <?php elseif($orders->status == '4'): ?>
                                <div class="text-success py-2">Completed</div>
                                <?php elseif($orders->status == '5'): ?>
                                <div class="text-danger py-2">Cancelled</div>
                                <?php endif; ?>
                                <label for="">NAME:</label>
                                <div class="py-2"> <?php echo e($orders->first_name); ?> <?php echo e($orders->last_name); ?> </div>
                                <label for="">EMAIL:</label>
                                <div class="py-2"> <?php echo e($orders->email); ?> </div>
                                <label for="">CONTACT NUMBER:</label>
                                <div class="py-2"> <?php echo e($orders->phone); ?> </div>
                                <label for="">SHIPPING ADDRESS:</label>
                                <div class="py-2"> 
                                    <?php echo e($orders->address_1); ?>, 
                                    <?php echo e($orders->address_2); ?>,
                                    <?php echo e($orders->address_city); ?>,
                                    <?php echo e($orders->address_province); ?>,
                                    <?php echo e($orders->zip_code); ?>,
                                </div>
                                <label for="">PAYMENT METHOD:</label>
                                <div class="py-2"> <?php echo e($orders->payment_mode); ?> </div>
                            </div>
                            <div class="col-md-6">
                                <h4>Order Details</h4>
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>Qty</th>
                                            <th>Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $orders->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <tr>
                                            <td>
                                                <img src="<?php echo e(asset('assets/uploads/products/'.$item->products->image)); ?>" alt="Image Here" height="50px">
                                                <?php echo e($item->products->name); ?> 
                                            </td> 
                                            <td><?php echo e($item->qty); ?></td> 
                                            <td>₱<?php echo e($item->price); ?>.00</td>                        
                                        </tr> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                                    </tbody>
                                </table>
                                <h4>Total: ₱<?php echo e($orders->total_price); ?>.00</h4>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Capstone\seafarmfresh\resources\views/frontend/orders/view.blade.php ENDPATH**/ ?>