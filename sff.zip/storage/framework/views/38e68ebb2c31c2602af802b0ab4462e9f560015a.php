

<?php $__env->startSection('title', "Blogs"); ?>

<?php $__env->startSection('content'); ?>


<?php $__env->startSection('content'); ?>
    <div class="py-5">
        <div class="container">
            <div class="row pt-5">
                <div class="">
                    <h2 class="blog_title categories_page_name mb-2">Blogs</h2>
                </div>
                <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                    <div class="col-md-3 mb-3">
                        <a href="<?php echo e(url('blog/'.$item->slug)); ?>">
                            <div class="card h-100">
                                <img src="<?php echo e(asset('assets/uploads/blog/'.$item->image)); ?>" alt="Product Image">
                                <div class="card-body">
                                    <h5><?php echo e($item->title); ?></h5>
                                    <p>
                                        <?php echo e($item->small_description); ?>

                                    </p>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Capstone\seafarmfresh\resources\views/frontend/blog.blade.php ENDPATH**/ ?>