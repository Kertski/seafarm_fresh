

<?php $__env->startSection('content'); ?>
    <div class='card'>
        <div  class='card-header edit_product_header'>
            <h4>
                Update  Product
            </h4>
        </div>
        <div  class='card-body'>
            <form action="<?php echo e(url('update-product/'.$products->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <label for="">Category</label>
                        <select class="form-select form-control">
                            <option value="<?php echo e($products->cat_id); ?>"><?php echo e($products->category->name); ?></option>          
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="">Name</label>
                        <input type="text" class="form-control" name="name" value="<?php echo e($products->name); ?>"/>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="">Slug</label>
                        <input type="text" class="form-control" name="slug" value="<?php echo e($products->slug); ?>"/>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="">Small Description</label>
                        <textarea name="small_description" row="3" class="form-control"><?php echo e($products->small_description); ?></textarea>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="">Description</label>
                        <textarea name="description" row="3" class="form-control"><?php echo e($products->description); ?></textarea>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="">Original Price</label>
                        <input type= "number" class="form-control" name="original_price" value="<?php echo e($products->original_price); ?>"/>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="">Selling Price</label>
                        <input type= "number" class="form-control" name="selling_price" value="<?php echo e($products->selling_price); ?>"/>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="">Tax</label>
                        <input type= "number" class="form-control" name="tax" value="<?php echo e($products->tax); ?>"/>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="">Active</label>
                        <input type= "checkbox" name="status" <?php echo e($products->status == "1" ? 'checked' : ''); ?>/>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="">Favorite</label>
                        <input type="checkbox" name="favorite" <?php echo e($products->favorite== "1" ? 'checked' : ''); ?>/>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="">Meta Title</label>
                        <input type="text" name="meta_title" class="form-control" value="<?php echo e($products->meta_title); ?>"/>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="">Meta Keywords</label>
                        <textarea name="meta_keywords" row="3" class="form-control"><?php echo e($products->meta_keywords); ?></textarea>
                    </div>
                    <div class="col-md-12">
                        <label for="">Meta Description</label>
                        <textarea type="text" name="meta_descript" class="form-control"><?php echo e($products->meta_descript); ?></textarea>
                    </div>
                    <div class="col-md-12">
                        <?php if($products->image): ?>
                            <img src="<?php echo e(asset('assets/uploads/products/'.$products->image)); ?>" alt="Product Image" width="300px"/>
                        <?php endif; ?>  
                    </div>                  
                    <div class="col-md-12">
                        <input type="file" name="image" class="form-control">
                    </div class="col-md-12">
                        <button type="submit" class="btn btn-primary m-3">Update</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Capstone\seafarmfresh\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>