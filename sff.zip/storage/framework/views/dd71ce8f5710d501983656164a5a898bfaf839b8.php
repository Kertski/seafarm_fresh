

<?php $__env->startSection('title', "Write a Review"); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="com-md-12">
            <div class="card review-card">
                <div class="card-body">
                    <?php if($verified_purchase->count() > 0): ?>
                        <h5>Write a Review for Seafarm Fresh <?php echo e($product->name); ?> :)</h5>
                        <form action="<?php echo e(url('/add-review')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                            <textarea class="form-control" name="user_review" rows="5" placeholder="Write a review"></textarea>
                            <button class="btn btn-rounded submit_review_btn" type="submit">Submit Review</button>
                        </form>
                    <?php else: ?>
                    <div class="alert alert-danger">
                        <h5>You are not eligible to review this product</h5>
                        <a href="<?php echo e(url('/')); ?> " class="btn btn-primary">Go to homepage</a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Capstone\seafarmfresh\resources\views/frontend/reviews/index.blade.php ENDPATH**/ ?>