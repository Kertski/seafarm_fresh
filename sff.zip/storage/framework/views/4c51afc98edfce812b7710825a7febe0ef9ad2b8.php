

<?php $__env->startSection('title'); ?>
    Welcome to Seafarm Fresh
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="py-5">
        <div class="container">
            <div class="row pt-5">
                <h2 class="categories_page_name">Products</h2>
                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 mb-3">
                            <a href="<?php echo e(url('view-category/'.$cat->slug)); ?>">
                                <div class="card h-100">
                                    <img src="<?php echo e(asset('assets/uploads/category/'.$cat->image)); ?>" alt="Product Image">
                                    <div class="card-body">
                                        <h5><?php echo e($cat->name); ?></h5>
                                    <p>
                                        <?php echo e($cat->description); ?>

                                    </p>
                                    </div>
                                </div>
                            </a>
                         </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Capstone\seafarmfresh\resources\views/frontend/category.blade.php ENDPATH**/ ?>