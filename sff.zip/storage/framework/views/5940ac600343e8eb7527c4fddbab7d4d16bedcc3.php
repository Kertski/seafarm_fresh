

<?php $__env->startSection('content'); ?>
    <div class='card'>
        <div  class='card-body'>
            <h1>
                Seafarm Fresh
            </h1>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Capstone\seafarmfresh\resources\views/admin/index.blade.php ENDPATH**/ ?>