

<?php $__env->startSection('title', "Edit Review"); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="com-md-12">
            <div class="card review-card">
                <div class="card-body">
                        <h5>Edit Review for Seafarm Fresh <?php echo e($review->product->name); ?></h5>
                        <form action="<?php echo e(url('/update-review')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <input type="hidden" name="review_id" value="<?php echo e($review->id); ?>">
                            <textarea class="form-control" name="user_review" rows="5" placeholder="Write a review"><?php echo e($review->user_review); ?></textarea>
                            <button type="submit" class="btn btn-rounded submit_review_btn mt-2">Update Review</button>
                        </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Capstone\seafarmfresh\resources\views/frontend/reviews/edit.blade.php ENDPATH**/ ?>