

<?php $__env->startSection('content'); ?>
    <div class='card'>
        <div class="card-header card_name_admin">
            <h4>CATEGORY</h4>
        </div>
        <br>
        <div  class='card-body'>
            <table class="table table-striped">
                <thead>
                    <tr class="column_name_admin">
                        <th>ID</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td class="category_name"><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->description); ?></td>
                        <?php if($item->status == '1'): ?>
                            <td class="text-success">Active</td>  
                        <?php elseif($item->status == '0'): ?>
                            <td class="text-danger">Inactive</td>  
                        <?php endif; ?>
                        <td>
                            <a href=" <?php echo e(url('edit-category/'.$item->id)); ?>" class="btn btn-primary">Edit</a>
                            
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Capstone\seafarmfresh\resources\views/admin/category/index.blade.php ENDPATH**/ ?>